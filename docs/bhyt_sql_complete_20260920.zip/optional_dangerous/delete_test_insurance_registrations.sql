-- Chỉ dùng cho database sandbox để xóa trọn dữ liệu test của các đơn đã chọn.
-- Không tắt FOREIGN_KEY_CHECKS: xóa đúng thứ tự giúp phát hiện quan hệ mới nếu có.

USE `iuoss_student_data_sandbox`;

START TRANSACTION;

-- Thẻ phát hành từ các đơn test cũng phải xóa để lần test sau không kế thừa thẻ.
DELETE FROM `student_health_insurance_cards`
WHERE `id` > 0
  AND `source_registration_id` IN (2, 3, 4, 5);

-- Hai bảng này cùng tham chiếu đơn và event, nên phải xóa trước event.
DELETE FROM `hub_insurance_payment_evidences`
WHERE `id` > 0
  AND `registration_id` IN (2, 3, 4, 5);

DELETE FROM `hub_insurance_payment_assessments`
WHERE `id` > 0
  AND `registration_id` IN (2, 3, 4, 5);

DELETE FROM `hub_insurance_registration_events`
WHERE `id` > 0
  AND `registration_id` IN (2, 3, 4, 5);

DELETE FROM `hub_insurance_registrations`
WHERE `id` IN (2, 3, 4, 5);

COMMIT;

-- Cả bốn truy vấn phải trả về 0 dòng.
SELECT `id` FROM `hub_insurance_registrations` WHERE `id` IN (2, 3, 4, 5);
SELECT `id` FROM `hub_insurance_registration_events` WHERE `registration_id` IN (2, 3, 4, 5);
SELECT `id` FROM `hub_insurance_payment_assessments` WHERE `registration_id` IN (2, 3, 4, 5);
SELECT `id` FROM `hub_insurance_payment_evidences` WHERE `registration_id` IN (2, 3, 4, 5);
