IUOSS BHYT SQL bundle - 2026-09-20

The sql/ directory contains the current SQL files.
The previous_bundle/ directory contains the previously delivered ZIP unchanged.
WARNING: optional_dangerous/delete_test_insurance_registrations.sql deletes test registration data and must not be run on production without review.
