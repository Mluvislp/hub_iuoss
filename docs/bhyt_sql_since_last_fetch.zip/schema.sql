-- IUOSS Hub — schema SQL
-- Chạy trên database iuoss_student_data (cùng DB với dashboard)
-- Tất cả bảng hub_ để tránh xung đột với schema hiện có

-- Bảng lưu thông tin đăng nhập student hub
CREATE TABLE IF NOT EXISTS `hub_students` (
  `id`             BIGINT       NOT NULL AUTO_INCREMENT,
  `ldap_uid`       VARCHAR(64)  NOT NULL,
  `student_id`     BIGINT       NULL,          -- soft ref → students.id
  `last_login_at`  DATETIME(6)  NULL,          -- lần đăng nhập gần nhất, bất kể lối nào
  `last_login_ldap_at` DATETIME(6) NULL,       -- riêng lối LDAP
  `last_login_ms_at`   DATETIME(6) NULL,       -- riêng lối Microsoft/Entra ID
  `login_count`    INT          NOT NULL DEFAULT 0,
  `created_at`     DATETIME(6)  NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_hub_students_uid` (`ldap_uid`),
  KEY `idx_hub_student_id` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bảng yêu cầu giấy xác nhận từ sinh viên
CREATE TABLE IF NOT EXISTS `hub_confirmation_requests` (
  `id`           BIGINT        NOT NULL AUTO_INCREMENT,
  `student_id`   BIGINT        NOT NULL,
  `ldap_uid`     VARCHAR(64)   NOT NULL,
  `request_type` VARCHAR(64)   NOT NULL,
  `purpose`      VARCHAR(255)  NOT NULL,
  `note`         TEXT          NULL,
  `payload`      JSON          NULL,           -- dữ liệu riêng theo từng loại giấy
  `status`       VARCHAR(16)   NOT NULL DEFAULT 'pending',
  `staff_note`   TEXT          NULL,
  `created_at`   DATETIME(6)   NOT NULL,
  `updated_at`   DATETIME(6)   NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_hcr_student_id` (`student_id`),
  KEY `idx_hcr_ldap_uid` (`ldap_uid`),
  KEY `idx_hcr_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sinh viên xin sửa CCCD / email / SĐT; nhân viên OSS duyệt bên Dashboard.
-- `target` cho biết sửa trường nào (registry CHANGE_TARGETS bên dashboard),
-- `group_key` gom nhiều dòng thuộc cùng một lần gửi.
-- Đây là bảng hub_* DUY NHẤT có khoá ngoại thật; 4 bảng còn lại chỉ soft ref.
CREATE TABLE IF NOT EXISTS `hub_profile_change_requests` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `student_id`     BIGINT        NOT NULL,
  `target`         VARCHAR(64)   NOT NULL,
  `target_id`      BIGINT        NULL,
  `old_value`      TEXT          NULL,
  `new_value`      TEXT          NOT NULL,
  `source`         VARCHAR(32)   NOT NULL,
  `group_key`      CHAR(32)      NULL,
  `status`         VARCHAR(16)   NOT NULL DEFAULT 'pending',
  `review_note`    VARCHAR(255)  NULL,
  `reviewed_by_id` INT           NULL,
  `reviewed_at`    DATETIME      NULL,
  `created_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_hpcr_user` (`reviewed_by_id`),
  KEY `idx_hpcr_queue` (`status`, `created_at`),
  KEY `idx_hpcr_student` (`student_id`, `target`, `status`),
  KEY `idx_hpcr_group` (`group_key`),
  CONSTRAINT `fk_hpcr_student` FOREIGN KEY (`student_id`)
    REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hpcr_user` FOREIGN KEY (`reviewed_by_id`)
    REFERENCES `auth_user` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bảng đăng ký BHYT từ sinh viên.
-- 11 cột từ `full_name` tới `permanent_street` chụp lại NGUYÊN TRẠNG thứ sinh
-- viên khai trên form; hồ sơ gốc trong `students` KHÔNG bị đơn này sửa (chênh
-- lệch nằm ở `change_log`). Tỉnh/phường lưu MÃ, tra tên khi hiển thị.
CREATE TABLE IF NOT EXISTS `hub_insurance_registrations` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `student_id` BIGINT NOT NULL,
  `registration_year` INT NOT NULL,
  `registration_period` VARCHAR(32) NOT NULL,
  `full_name` VARCHAR(255) NULL,
  `student_code` VARCHAR(64) NULL,
  `gender` VARCHAR(10) NULL,
  `dob` DATE NULL,
  `ethnicity` VARCHAR(64) NULL,
  `phone_number` VARCHAR(20) NULL,
  `citizen_id` VARCHAR(20) NULL,
  `social_insurance_number` VARCHAR(20) NULL,
  `permanent_province` VARCHAR(32) NULL,
  `permanent_ward` VARCHAR(32) NULL,
  `permanent_street` VARCHAR(255) NULL,
  `hospital_code` VARCHAR(16) NOT NULL,
  `cccd_image` VARCHAR(500) NULL COMMENT 'Ảnh CCCD mặt trước',
  `cccd_image_back` VARCHAR(500) NULL COMMENT 'Ảnh CCCD mặt sau',
  `bhyt_image` VARCHAR(500) NULL,
  `payment_receipt_image` VARCHAR(500) NOT NULL,
  `change_log` JSON NULL,
  `config_snapshot` JSON NULL COMMENT 'Cấu hình phí/ngân hàng tại thời điểm nộp',
  `status` VARCHAR(16) NOT NULL DEFAULT 'pending',
  `rejection_reason` TEXT NULL,
  `created_at` DATETIME(6) NOT NULL,
  `updated_at` DATETIME(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_hir_student_id` (`student_id`),
  KEY `idx_hir_period_year` (`registration_year`, `registration_period`),
  KEY `idx_hir_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dữ liệu đọc từ mã QR trên thẻ CCCD. Bảng DÙNG CHUNG cho mọi luồng có thu
-- thập CCCD; `source` cho biết thu ở đâu, `source_ref_id` trỏ về bản ghi gốc.
-- Ghi thêm dòng mỗi lần quét, không sửa đè.
CREATE TABLE IF NOT EXISTS `hub_cccd_scans` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `student_id` BIGINT NOT NULL,
  `source` VARCHAR(32) NOT NULL COMMENT 'bhyt_registration, offcampus, ...',
  `source_ref_id` BIGINT NULL COMMENT 'Id bản ghi ở luồng thu thập',
  `citizen_id` VARCHAR(12) NOT NULL,
  `old_id_number` VARCHAR(12) NULL COMMENT 'CMND 9 số in trên thẻ, có thể rỗng',
  `full_name` VARCHAR(255) NOT NULL,
  `date_of_birth` DATE NULL,
  `gender` VARCHAR(10) NULL,
  `residence_address` VARCHAR(255) NULL COMMENT 'Nguyên văn trên thẻ, cơ cấu hành chính TRƯỚC 2025',
  `issue_date` DATE NULL,
  `raw_payload` VARCHAR(512) NULL COMMENT 'Chuỗi QR gốc, để dựng lại nếu bộ đọc sai',
  `scanned_at` DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_cccd_student` (`student_id`),
  KEY `idx_cccd_citizen` (`citizen_id`),
  KEY `idx_cccd_source` (`source`, `source_ref_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Danh sách tài khoản nhận phí do IT quản lý; staff chỉ được chọn trên Dashboard.
CREATE TABLE IF NOT EXISTS `hub_insurance_bank_accounts` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `bank_name` VARCHAR(255) NOT NULL,
  `bank_bin` VARCHAR(6) NOT NULL,
  `account_number` VARCHAR(64) NOT NULL,
  `account_name` VARCHAR(255) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_hiba_account` (`bank_bin`, `account_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bốn slot MAIN/Q2/Q3/Q4 được staff cập nhật và tái sử dụng qua từng năm.
CREATE TABLE IF NOT EXISTS `hub_insurance_configs` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `registration_period` VARCHAR(32) NOT NULL,
  `registration_year` INT NOT NULL,
  `registration_opens_at` DATETIME(6) NOT NULL,
  `registration_closes_at` DATETIME(6) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 0,
  `bank_account_id` BIGINT NULL,
  `description` TEXT NULL,
  `bank_name` VARCHAR(255) NOT NULL,
  `bank_bin` VARCHAR(6) NULL COMMENT 'Mã BIN 6 số của Napas, dùng dựng VietQR',
  `bank_account_number` VARCHAR(64) NOT NULL,
  `bank_account_name` VARCHAR(255) NOT NULL,
  `insurance_fee` INT NOT NULL COMMENT 'Đơn vị: VNĐ',
  `created_at` DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_hic_period` (`registration_period`),
  KEY `idx_hic_bank_account` (`bank_account_id`),
  CONSTRAINT `fk_hic_bank_account` FOREIGN KEY (`bank_account_id`)
    REFERENCES `hub_insurance_bank_accounts` (`id`) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT `chk_hic_period` CHECK (`registration_period` IN ('MAIN','Q2','Q3','Q4'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bảng session cho hub (tách biệt với dashboard sessions)
-- Django tự tạo bảng này khi chạy: python manage.py migrate
-- (django.contrib.sessions dùng migration riêng, không bị tắt bởi MIGRATION_MODULES)

-- BHYT workflow v2: after this base schema and the card/bank upgrade, run
-- docs/insurance_workflow_upgrade.sql (idempotent expand; no data deletion).
